// index.js - Main entry point
export { default as LambdaHooks } from './lib/lambda-hooks.js';